<?php

/* login.html */
class __TwigTemplate_c75ceef9aa7bfae7e5cc9b05d66f92e31f6a48ce6d3a2309af6693d720333a94 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<html>
<head>


  <meta charset=\"utf-8\">
  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
  <title>Login - Media Belajar Online SMP IA</title>
  <link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, (isset($context["favicon_url"]) ? $context["favicon_url"] : null), "html", null, true);
        echo "\">
  <link type=\"text/css\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, base_url("assets/adminlte/plugins/fontawesome-free/css/all.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
  
  <!-- Font Awesome -->
  <link type=\"text/css\" href=\"";
        // line 13
        echo twig_escape_filter($this->env, base_url("assets/adminlte/plugins/fontawesome-free/css/all.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
  
  <!-- Ionicons -->
  <link type=\"text/css\" href=\"https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css\" rel=\"stylesheet\">
 
  <!-- Theme style -->
  <link type=\"text/css\" href=\"";
        // line 19
        echo twig_escape_filter($this->env, base_url("assets/adminlte/dist/css/adminlte.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
  
  <!-- Google Font: Source Sans Pro -->
  <link type=\"text/css\" href=\"https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700\" rel=\"stylesheet\">
  
</head>
<body class=\"hold-transition login-page\" style=\"background: url(http://smp-ia.sch.id/elearning/assets/themes/default/images/bg2.png) #eee; background-attachment: fixed;background-size: cover;background-repeat: no-repeat;\">
<div class=\"login-box\">
  <div class=\"login-logo\">
    <img src=\"";
        // line 28
        echo twig_escape_filter($this->env, get_logo_config(), "html", null, true);
        echo "\" width=\"130px\">
    
  </div>
  <!-- /.login-logo -->
  <div class=\"card\">

    <div class=\"card-body login-card-body\">

 <p class=\"login-box-msg\">Silahkan login terlebih dahulu</p>
      ";
        // line 37
        echo get_flashdata("login");
        echo "

      ";
        // line 39
        echo form_open("login", array("autocomplete" => "off", "class" => "form-vertical"));
        echo "
        <div class=\"input-group mb-3\">
          <input type=\"email\" class=\"form-control\" placeholder=\"Username (Email)\" value=\"";
        // line 41
        echo twig_escape_filter($this->env, set_value("email"), "html", null, true);
        echo "\" autofocus required=\"\" name=\"email\">
          <div class=\"input-group-append\">
            <div class=\"input-group-text\">
              <span class=\"fas fa-user\"></span>
            </div>
          </div>
        </div>
        <div class=\"input-group mb-3\">
          <input type=\"password\" class=\"form-control\" placeholder=\"Password\" name=\"password\" required=\"\">
          <div class=\"input-group-append\">
            <div class=\"input-group-text\">
              <span class=\"fas fa-lock\"></span>
            </div>
          </div>
        </div>

        <div class=\"row\">
          <div class=\"col-8\"></div>
          
          <div class=\"col-4\">
            <button type=\"submit\" class=\"btn btn-primary btn-block btn-flat\">Log In</button>
          </div>
        </div>


    </div>
    <!-- /.login-card-body -->
  </div><br><br>
  <center><small><b>Media Belajar Online</b><br>
       ";
        // line 70
        echo twig_escape_filter($this->env, (isset($context["site_name"]) ? $context["site_name"] : null), "html", null, true);
        echo "<br>
        <span style=\"color: grey\"> &copy; 2020 SMP Islam As-Sunnah Bagek Nyaka</span>
    </small>
    </center>
</div>
";
        // line 75
        echo form_close();
        echo "
<!-- /.login-box -->

<!-- jQuery -->
<script type=\"text/javascript\">
var site_url = \"";
        // line 80
        echo twig_escape_filter($this->env, site_url(), "html", null, true);
        echo "\";
var base_url = \"";
        // line 81
        echo twig_escape_filter($this->env, base_url(), "html", null, true);
        echo "\";
</script>
<script src=\"";
        // line 83
        echo twig_escape_filter($this->env, base_url("assets/comp/jquery/jquery.js"), "html", null, true);
        echo "\" type=\"text/javascript\"></script>
<script src=\"";
        // line 84
        echo twig_escape_filter($this->env, base_url("assets/adminlte/plugins/bootstrap/js/bootstrap.bundle.min.js"), "html", null, true);
        echo "\" type=\"text/javascript\"></script>

</body>
</html>

<!-- 
<div class=\"row\">
    ";
        // line 91
        if ((!twig_test_empty((isset($context["sliders"]) ? $context["sliders"] : null)))) {
            // line 92
            echo "    <div class=\"span5 offset1\">
        <div class=\"slider-wrapper theme-light\">
            <div id=\"slider-login\" class=\"nivoSlider\">
                ";
            // line 95
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["sliders"]) ? $context["sliders"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["s"]) {
                // line 96
                echo "                <img src=\"";
                echo twig_escape_filter($this->env, get_url_image($this->getAttribute((isset($context["s"]) ? $context["s"] : null), "value")), "html", null, true);
                echo "\" data-thumb=\"";
                echo twig_escape_filter($this->env, get_url_image($this->getAttribute((isset($context["s"]) ? $context["s"] : null), "value")), "html", null, true);
                echo "\" title=\"#html";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["s"]) ? $context["s"] : null), "id"), "html", null, true);
                echo "\">
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['s'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 98
            echo "            </div>
            ";
            // line 99
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["sliders"]) ? $context["sliders"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["s"]) {
                // line 100
                echo "            <div id=\"html";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["s"]) ? $context["s"] : null), "id"), "html", null, true);
                echo "\" class=\"nivo-html-caption\">
                ";
                // line 101
                echo $this->getAttribute((isset($context["s"]) ? $context["s"] : null), "title");
                echo "
            </div>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['s'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 104
            echo "        </div>
    </div>
    ";
        }
        // line 107
        echo "
    <div class=\"module span4 ";
        // line 108
        echo ((twig_test_empty((isset($context["sliders"]) ? $context["sliders"] : null))) ? ("offset4") : (""));
        echo "\">
        ";
        // line 109
        echo form_open("login", array("autocomplete" => "off", "class" => "form-vertical"));
        echo "
            <div class=\"module-head\" style=\"background-color: #143db4\">
                <h3 style=\"color: white\">Login</h3>
            </div>
            <div class=\"module-body\">
               ";
        // line 114
        echo get_flashdata("login");
        echo "
                <div class=\"control-group\">
                    <div class=\"controls row-fluid\">
                        <input class=\"span12\" name=\"email\" type=\"text\" placeholder=\"Username (Email)\" value=\"";
        // line 117
        echo twig_escape_filter($this->env, set_value("email"), "html", null, true);
        echo "\" autofocus>
                        ";
        // line 118
        echo form_error("email");
        echo "
                    </div>
                </div>
                <div class=\"control-group\">
                    <div class=\"controls row-fluid\">
                        <input class=\"span12\" name=\"password\" type=\"password\" placeholder=\"Password\">
                    </div>
                </div>
            </div>
            <div class=\"module-foot\">
                <div class=\"control-group\">
                    <div class=\"controls clearfix\">
                        <button type=\"submit\" class=\"btn btn-large btn-primary pull-right\">Login</button>
                        ";
        // line 131
        if (((get_pengaturan("registrasi-siswa", "value") == 1) || (get_pengaturan("registrasi-pengajar", "value") == 1))) {
            // line 132
            echo "                        <a href=\"";
            echo twig_escape_filter($this->env, site_url("login/lupa_password"), "html", null, true);
            echo "\">Lupa password?</a> <br>Belum punya akun? <a href=\"";
            echo twig_escape_filter($this->env, site_url("login/register"), "html", null, true);
            echo "\">Register</a> sekarang.
                        ";
        }
        // line 134
        echo "                    </div>
                </div>
            </div>
        ";
        // line 137
        echo form_close();
        echo "
    </div>
</div> -->

";
    }

    public function getTemplateName()
    {
        return "login.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  259 => 137,  254 => 134,  246 => 132,  244 => 131,  228 => 118,  224 => 117,  218 => 114,  210 => 109,  206 => 108,  203 => 107,  198 => 104,  189 => 101,  184 => 100,  180 => 99,  177 => 98,  164 => 96,  160 => 95,  155 => 92,  153 => 91,  143 => 84,  139 => 83,  134 => 81,  130 => 80,  122 => 75,  114 => 70,  82 => 41,  77 => 39,  72 => 37,  60 => 28,  48 => 19,  39 => 13,  33 => 10,  29 => 9,  19 => 1,);
    }
}

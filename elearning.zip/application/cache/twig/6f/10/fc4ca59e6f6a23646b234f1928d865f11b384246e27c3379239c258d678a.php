<?php

/* layout-ujian.html */
class __TwigTemplate_6f10fc4ca59e6f6a23646b234f1928d865f11b384246e27c3379239c258d678a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
            'js' => array($this, 'block_js'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
    <head>
        ";
        // line 4
        $this->env->loadTemplate("layout-header.html")->display($context);
        // line 5
        echo "        <link type=\"text/css\" href=\"";
        echo twig_escape_filter($this->env, (isset($context["base_url_theme"]) ? $context["base_url_theme"] : null), "html", null, true);
        echo "css/read.css\" rel=\"stylesheet\">
        <link type=\"text/css\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, (isset($context["base_url_theme"]) ? $context["base_url_theme"] : null), "html", null, true);
        echo "css/theme.css\" rel=\"stylesheet\">
        ";
        // line 7
        $this->displayBlock('css', $context, $blocks);
        // line 8
        echo "    </head>
    <body>

        ";
        // line 11
        $this->displayBlock('content', $context, $blocks);
        // line 12
        echo "
        <br><br>
        <!--/.wrapper-->
        <div class=\"footer\">
            <div class=\"container\">
                <center>
                    <b class=\"copyright\">SMP Islam As-Sunnah Bagek Nyaka</b> &copy; 2020<br>
                    by Harianto Rais
                </center>
            </div>
        </div>

        ";
        // line 24
        $this->env->loadTemplate("layout-footer.html")->display($context);
        // line 25
        echo "        ";
        $this->displayBlock('js', $context, $blocks);
        // line 26
        echo "    </body>
</html>
";
    }

    // line 7
    public function block_css($context, array $blocks = array())
    {
    }

    // line 11
    public function block_content($context, array $blocks = array())
    {
    }

    // line 25
    public function block_js($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "layout-ujian.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  82 => 25,  72 => 7,  66 => 26,  63 => 25,  61 => 24,  47 => 12,  45 => 11,  38 => 7,  34 => 6,  27 => 4,  22 => 1,  451 => 208,  447 => 207,  443 => 206,  439 => 205,  435 => 204,  432 => 203,  430 => 202,  423 => 197,  404 => 181,  393 => 172,  369 => 166,  363 => 163,  357 => 160,  352 => 159,  335 => 158,  328 => 154,  320 => 149,  315 => 148,  313 => 147,  309 => 145,  300 => 139,  280 => 121,  259 => 113,  248 => 109,  231 => 107,  228 => 106,  223 => 105,  217 => 102,  211 => 99,  205 => 96,  200 => 95,  183 => 94,  176 => 90,  170 => 86,  168 => 85,  164 => 83,  158 => 80,  150 => 75,  144 => 72,  138 => 69,  128 => 62,  123 => 59,  101 => 40,  98 => 39,  94 => 37,  90 => 35,  87 => 34,  85 => 33,  77 => 11,  73 => 26,  71 => 25,  60 => 17,  56 => 16,  49 => 12,  43 => 8,  40 => 8,  32 => 4,  29 => 5,);
    }
}

<?php

/* list-materi.html */
class __TwigTemplate_7f857167ed078456c7dacce5699c3c84c4bbedc1d2c03ce6f2834231bba6a50b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-private.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-private.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "Materi - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "<div class=\"module\">
    <div class=\"module-head\">
        <h3>Materi</h3>
    </div>
    <div class=\"module-body\">
        ";
        // line 13
        echo get_flashdata("materi");
        echo "

        <div class=\"bs-callout bs-callout-warning\">
            <b><a class=\"as-link\" data-toggle=\"collapse\" data-target=\"#form-filter\"><i class=\"icon-search\" style=\"line-height: 0px;\"></i> CARI MATERI</a></b>

            <div id=\"form-filter\" class=\"collapse\" style=\"margin-top: 5px;\">
                ";
        // line 19
        echo form_open("materi");
        echo "
                    <table class=\"table table-condensed\">
                        <tr>
                            <th  style=\"border-top: none;\">Mapel</th>
                            <td  style=\"border-top: none;\">
                                <ul class=\"unstyled inline\" style=\"margin-left: -5px;\">
                                    ";
        // line 25
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["mapel"]) ? $context["mapel"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["m"]) {
            // line 26
            echo "                                    <li>
                                        <label class=\"checkbox inline\">
                                            <input type=\"checkbox\" name=\"mapel_id[]\" value=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id"), "html", null, true);
            echo "\" ";
            echo twig_escape_filter($this->env, set_checkbox("mapel_id[]", $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id"), ((((!twig_test_empty($this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "mapel_id"))) && in_array($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id"), $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "mapel_id")))) ? (true) : (""))), "html", null, true);
            echo "> ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "nama"), "html", null, true);
            echo "
                                        </label>
                                    </li>
                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['m'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "                                </ul>
                            </td>
                        </tr>
                        <tr>
                            <th>Kelas</th>
                            <td>
                                <ul class=\"unstyled inline\" style=\"margin-left: -5px;\">
                                    ";
        // line 39
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["kelas"]) ? $context["kelas"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["k"]) {
            // line 40
            echo "                                    <li>
                                        <label class=\"checkbox inline\">
                                            <input type=\"checkbox\" name=\"kelas_id[]\" value=\"";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"), "html", null, true);
            echo "\" ";
            echo twig_escape_filter($this->env, set_checkbox("kelas_id[]", $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"), ((((!twig_test_empty($this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "kelas_id"))) && in_array($this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"), $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "kelas_id")))) ? (true) : (""))), "html", null, true);
            echo "> ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "nama"), "html", null, true);
            echo "
                                        </label>
                                    </li>
                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['k'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 46
        echo "                                </ul>
                            </td>
                        </tr>
                        <tr>
                            <th>Tipe</th>
                            <td>
                                <ul class=\"unstyled inline\" style=\"margin-left: -5px;\">
                                    <li>
                                        <label class=\"checkbox inline\">
                                            <input type=\"checkbox\" name=\"type[]\" value=\"tertulis\" ";
        // line 55
        echo twig_escape_filter($this->env, set_checkbox("type[]", "tertulis", ((((!twig_test_empty($this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "type"))) && in_array("tertulis", $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "type")))) ? (true) : (""))), "html", null, true);
        echo "> Tertulis
                                        </label>
                                    </li>
                                    <li>
                                        <label class=\"checkbox inline\">
                                            <input type=\"checkbox\" name=\"type[]\" value=\"file\" ";
        // line 60
        echo twig_escape_filter($this->env, set_checkbox("type[]", "file", ((((!twig_test_empty($this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "type"))) && in_array("file", $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "type")))) ? (true) : (""))), "html", null, true);
        echo "> File
                                        </label>
                                    </li>
                                </ul>
                            </td>
                        </tr>
                        <tr>
                            <th width=\"15%\">Judul</th>
                            <td>
                                <input type=\"text\" name=\"judul\" class=\"span4\" value=\"";
        // line 69
        echo twig_escape_filter($this->env, set_value("judul", $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "judul")), "html", null, true);
        echo "\">
                            </td>
                        </tr>
                        <tr>
                            <th>Konten</th>
                            <td>
                                <input type=\"text\" name=\"konten\" class=\"span5\" value=\"";
        // line 75
        echo twig_escape_filter($this->env, set_value("konten", $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "konten")), "html", null, true);
        echo "\">
                            </td>
                        </tr>
                        ";
        // line 78
        if ((is_admin() == true)) {
            // line 79
            echo "                        <tr>
                            <th>Pembuat</th>
                            <td>
                                <input type=\"text\" name=\"pembuat\" class=\"span4\" value=\"";
            // line 82
            echo twig_escape_filter($this->env, set_value("pembuat", $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "pembuat")), "html", null, true);
            echo "\">
                            </td>
                        </tr>
                        ";
        }
        // line 86
        echo "                        <tr>
                            <th>Status</th>
                            <td>
                                <ul class=\"unstyled inline\" style=\"margin-left: -5px;\">
                                    <li>
                                        <label class=\"checkbox inline\">
                                            <input type=\"checkbox\" name=\"publish[]\" value=\"1\" ";
        // line 92
        echo twig_escape_filter($this->env, set_checkbox("publish[]", "1", ((((!twig_test_empty($this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "publish"))) && in_array("1", $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "publish")))) ? (true) : (""))), "html", null, true);
        echo "> Terbit
                                        </label>
                                    </li>
                                    <li>
                                        <label class=\"checkbox inline\">
                                            <input type=\"checkbox\" name=\"publish[]\" value=\"0\" ";
        // line 97
        echo twig_escape_filter($this->env, set_checkbox("publish[]", "0", ((((!twig_test_empty($this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "publish"))) && in_array("0", $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "publish")))) ? (true) : (""))), "html", null, true);
        echo "> Konsep
                                        </label>
                                    </li>
                                </ul>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>
                                <button type=\"submit\" class=\"btn btn-primary\">Filter</button>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>

        </div>
        <br>

        ";
        // line 116
        if ((is_siswa() == false)) {
            // line 117
            echo "            <div class=\"btn-group pull-left\" style=\"margin-top:-5px;\">
                ";
            // line 118
            echo anchor("materi/add/tertulis", "<i class=\"icon-pencil\"></i>Tambah Materi Tertulis", array("class" => "btn btn-primary"));
            echo "
                ";
            // line 119
            echo anchor("materi/add/file", "<i class=\"icon-file\"></i>Tambah Materi File", array("class" => "btn btn-success"));
            echo "
            </div>
            ";
        }
        // line 121
        echo "<br><br>

        

        <table class=\"table table-striped table-hover\">
            <thead>
                <tr>
                    ";
        // line 128
        if ((is_siswa() == true)) {
            // line 129
            echo "                    <th>Daftar Materi</th>
                    ";
        } else {
            // line 131
            echo "                    <th width=\"7%\">ID</th>
                    <th>Daftar Materi</th>
                    ";
        }
        // line 134
        echo "                </tr>
            </thead>
            <tbody>
                ";
        // line 137
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["materi"]) ? $context["materi"] : null));
        foreach ($context['_seq'] as $context["no"] => $context["m"]) {
            // line 138
            echo "
                ";
            // line 139
            if ((is_admin() == true)) {
                // line 140
                echo "                    ";
                $context["action_edit"] = true;
                // line 141
                echo "                    ";
                $context["action_delete"] = true;
                // line 142
                echo "                ";
            } elseif ((is_pengajar() == true)) {
                // line 143
                echo "                    ";
                if (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "pengajar_id") == get_sess_data("user", "id"))) {
                    // line 144
                    echo "                        ";
                    $context["action_edit"] = true;
                    // line 145
                    echo "                        ";
                    $context["action_delete"] = true;
                    // line 146
                    echo "                    ";
                } else {
                    // line 147
                    echo "                        ";
                    $context["action_edit"] = false;
                    // line 148
                    echo "                        ";
                    $context["action_delete"] = false;
                    // line 149
                    echo "                    ";
                }
                // line 150
                echo "                ";
            } elseif ((is_siswa() == true)) {
                // line 151
                echo "                    ";
                if (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "siswa_id") == get_sess_data("user", "id"))) {
                    // line 152
                    echo "                        ";
                    $context["action_edit"] = true;
                    // line 153
                    echo "                        ";
                    $context["action_delete"] = true;
                    // line 154
                    echo "                    ";
                } else {
                    // line 155
                    echo "                        ";
                    $context["action_edit"] = false;
                    // line 156
                    echo "                        ";
                    $context["action_delete"] = false;
                    // line 157
                    echo "                    ";
                }
                // line 158
                echo "                ";
            }
            // line 159
            echo "
                
                    ";
            // line 161
            if ((is_siswa() == true)) {
                // line 162
                echo "                    <tr class=\"clickable-row\" data-href=\"";
                echo twig_escape_filter($this->env, site_url(("materi/detail/" . $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id"))), "html", null, true);
                echo "\">
                    
                    <td>
                        <strong class=\"text-warning\">
                        <a href=\"";
                // line 166
                echo twig_escape_filter($this->env, site_url(("materi/detail/" . $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "judul"), "html", null, true);
                echo "</a>
                        </strong><br>
                        
                                <small>Mapel: <b>";
                // line 169
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel"), "nama"), "html", null, true);
                echo "</b>,
                                    diposting oleh: <a href=\"";
                // line 170
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "pembuat"), "link_profil"), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "pembuat"), "nama"), "html", null, true);
                echo "</a>, ";
                echo twig_escape_filter($this->env, tgl_jam_indo($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "tgl_posting")), "html", null, true);
                echo " <br>
                                ";
                // line 171
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "jml_komentar"), "html", null, true);
                echo " Komentar
                                </small>
                            
                    </td>
                    </tr>


                    ";
            } else {
                // line 179
                echo "                    <tr>
                    <td><b>";
                // line 180
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id"), "html", null, true);
                echo "</b></td>
                    <td>
                        
                        ";
                // line 183
                if (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "publish") == 0)) {
                    // line 184
                    echo "                        <strong style=\"color: grey\"><a href=\"";
                    echo twig_escape_filter($this->env, site_url(("materi/detail/" . $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id"))), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "judul"), "html", null, true);
                    echo "</a></strong>


                        ";
                } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "publish") == 1)) {
                    // line 188
                    echo "                        <strong style=\"color: green\"><a href=\"";
                    echo twig_escape_filter($this->env, site_url(("materi/detail/" . $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id"))), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "judul"), "html", null, true);
                    echo "</a></strong>
                        
                        ";
                }
                // line 191
                echo "                        
                                ";
                // line 192
                echo ((($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "publish") == 1)) ? ("<span class=\"badge badge-success\">Terbit</span>") : ("<span class=\"badge badge-danger\">Konsep</span>"));
                echo "
                        <br>
                        
                        
                                ";
                // line 196
                echo (((!twig_test_empty($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "file")))) ? ("<span style=\"color: blue\">File</span>") : ("<span style=\"color: green\">Tertulis</span>"));
                echo ", 
                        
                                ";
                // line 198
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel"), "nama"), "html", null, true);
                echo ", 
                        
                                ";
                // line 200
                $context['_parent'] = (array) $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "materi_kelas"));
                foreach ($context['_seq'] as $context["_key"] => $context["mk"]) {
                    // line 201
                    echo "                                    ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["mk"]) ? $context["mk"] : null), "nama"), "html", null, true);
                    echo "&nbsp;
                                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['mk'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 202
                echo ", 
                        
                                ";
                // line 204
                if ((is_pengajar() == false)) {
                    // line 205
                    echo "                                    Pembuat <a href=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "pembuat"), "link_profil"), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "pembuat"), "nama"), "html", null, true);
                    echo "</a>
                                    , ";
                    // line 206
                    echo twig_escape_filter($this->env, tgl_jam_indo($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "tgl_posting")), "html", null, true);
                    echo ",
                                ";
                } else {
                    // line 208
                    echo "                                    Dibuat ";
                    echo twig_escape_filter($this->env, tgl_jam_indo($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "tgl_posting")), "html", null, true);
                    echo ",
                                ";
                }
                // line 209
                echo " 
                        
                                ";
                // line 211
                echo ((twig_test_empty($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "file"))) ? ("Dibaca") : ("Diunduh"));
                echo "
                                ";
                // line 212
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "views"), "html", null, true);
                echo " kali, 
                        
                                ";
                // line 214
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "jml_komentar"), "html", null, true);
                echo " Komentar
                        

                         <!-- dropdown -->
                         ";
                // line 218
                if ((is_siswa() == false)) {
                    // line 219
                    echo "                   
                        
                            <ul class=\"nav\">
                            <li class=\"nav-user dropdown\">
                                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\"><b class=\"caret\"></b></a>
                            
                                <ul class=\"dropdown-menu\">

                                    ";
                    // line 227
                    if ((!twig_test_empty($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "file")))) {
                        // line 228
                        echo "                                        ";
                        $context["url_type"] = "file";
                        // line 229
                        echo "                                    ";
                    } else {
                        // line 230
                        echo "                                        ";
                        $context["url_type"] = "tertulis";
                        // line 231
                        echo "                                    ";
                    }
                    // line 232
                    echo "                                    

                                   <!--  <li>";
                    // line 234
                    echo anchor(("materi/detail/" . $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id")), "<i class=\"icon-zoom-in\"></i> Lihat Materi");
                    echo "</li> -->

                                    <li> ";
                    // line 236
                    echo anchor(("materi/absen/" . $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id")), "<i class=\"icon-group\"></i> Kehadiran");
                    echo "</li>

                                    ";
                    // line 238
                    if (((isset($context["action_edit"]) ? $context["action_edit"] : null) == true)) {
                        // line 239
                        echo "                                        <li>";
                        echo anchor(((((("materi/edit/" . (isset($context["url_type"]) ? $context["url_type"] : null)) . "/") . $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id")) . "/") . enurl_redirect(current_url())), "<i class=\"icon-edit\"></i> Edit");
                        echo "</li>
                                    ";
                    }
                    // line 241
                    echo "
                                    ";
                    // line 242
                    if ((is_admin() == true)) {
                        // line 243
                        echo "                                        ";
                        if (((isset($context["action_delete"]) ? $context["action_delete"] : null) == true)) {
                            // line 244
                            echo "                                            <li>";
                            echo anchor(((("materi/delete/" . $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id")) . "/") . enurl_redirect(current_url())), "<i style=\"color: red\" class=\"icon-trash\"></i> <span style=\"color: red\">Hapus</span>", array("onclick" => "return confirm('Anda yakin ingin menghapus?')"));
                            echo "</li>
                                        ";
                        }
                        // line 246
                        echo "                                    ";
                    }
                    // line 247
                    echo "                                    
                                </ul>
                            </li>
                            </ul>
              
                        ";
                }
                // line 253
                echo "
                    </td>
                    

                        ";
            }
            // line 258
            echo "
                       
                </tr>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['no'], $context['m'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 262
        echo "            </tbody>
        </table>
        <br>
        ";
        // line 265
        echo (isset($context["pagination"]) ? $context["pagination"] : null);
        echo "

    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "list-materi.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  570 => 265,  565 => 262,  556 => 258,  549 => 253,  541 => 247,  538 => 246,  532 => 244,  529 => 243,  527 => 242,  524 => 241,  518 => 239,  516 => 238,  511 => 236,  506 => 234,  502 => 232,  499 => 231,  496 => 230,  493 => 229,  490 => 228,  488 => 227,  478 => 219,  476 => 218,  469 => 214,  464 => 212,  460 => 211,  456 => 209,  450 => 208,  445 => 206,  438 => 205,  436 => 204,  432 => 202,  423 => 201,  419 => 200,  414 => 198,  409 => 196,  402 => 192,  399 => 191,  390 => 188,  380 => 184,  378 => 183,  372 => 180,  369 => 179,  358 => 171,  350 => 170,  346 => 169,  338 => 166,  330 => 162,  328 => 161,  324 => 159,  321 => 158,  318 => 157,  315 => 156,  312 => 155,  309 => 154,  306 => 153,  303 => 152,  300 => 151,  297 => 150,  294 => 149,  291 => 148,  288 => 147,  285 => 146,  282 => 145,  279 => 144,  276 => 143,  273 => 142,  270 => 141,  267 => 140,  265 => 139,  262 => 138,  258 => 137,  253 => 134,  248 => 131,  244 => 129,  242 => 128,  233 => 121,  227 => 119,  223 => 118,  220 => 117,  218 => 116,  196 => 97,  188 => 92,  180 => 86,  173 => 82,  168 => 79,  166 => 78,  160 => 75,  151 => 69,  139 => 60,  131 => 55,  120 => 46,  106 => 42,  102 => 40,  98 => 39,  89 => 32,  75 => 28,  71 => 26,  67 => 25,  58 => 19,  49 => 13,  42 => 8,  39 => 7,  32 => 4,  29 => 3,);
    }
}

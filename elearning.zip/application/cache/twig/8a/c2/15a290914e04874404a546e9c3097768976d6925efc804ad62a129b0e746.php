<?php

/* list-tugas.html */
class __TwigTemplate_8ac215a290914e04874404a546e9c3097768976d6925efc804ad62a129b0e746 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-private.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-private.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "Tugas - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "<div class=\"module\">
    <div class=\"module-head\">
        <h3>Tugas</h3>
    </div>
    <div class=\"module-body\">
        ";
        // line 13
        echo get_flashdata("tugas");
        echo "

        ";
        // line 15
        if ((is_siswa() == false)) {
            // line 16
            echo "        <div class=\"bs-callout bs-callout-info\">
            
            <b><a class=\"as-link\" data-toggle=\"collapse\" data-target=\"#form-filter\"><i class=\"icon-search\" style=\"line-height: 0px;\"></i> CARI TUGAS</a></b>
            

            <div id=\"form-filter\" class=\"collapse\" style=\"margin-top: 5px;\">
                ";
            // line 22
            echo form_open("tugas");
            echo "
                    <table class=\"table table-condensed\">
                        <tr>
                            <th  style=\"border-top: none;\">Mapel</th>
                            <td  style=\"border-top: none;\">
                                <ul class=\"unstyled inline\" style=\"margin-left: -5px;\">
                                    ";
            // line 28
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["mapel"]) ? $context["mapel"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["m"]) {
                // line 29
                echo "                                    <li>
                                        <label class=\"checkbox inline\">
                                            <input type=\"checkbox\" name=\"mapel_id[]\" value=\"";
                // line 31
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id"), "html", null, true);
                echo "\" ";
                echo twig_escape_filter($this->env, set_checkbox("mapel_id[]", $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id"), ((((!twig_test_empty($this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "mapel_id"))) && in_array($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id"), $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "mapel_id")))) ? (true) : (""))), "html", null, true);
                echo "> ";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "nama"), "html", null, true);
                echo "
                                        </label>
                                    </li>
                                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['m'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 35
            echo "                                </ul>
                            </td>
                        </tr>
                        ";
            // line 38
            if ((is_siswa() == false)) {
                // line 39
                echo "                        <tr>
                            <th>Kelas</th>
                            <td>
                                <ul class=\"unstyled inline\" style=\"margin-left: -5px;\">
                                    ";
                // line 43
                $context['_parent'] = (array) $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["kelas"]) ? $context["kelas"] : null));
                foreach ($context['_seq'] as $context["_key"] => $context["k"]) {
                    // line 44
                    echo "                                    <li>
                                        <label class=\"checkbox inline\">
                                            <input type=\"checkbox\" name=\"kelas_id[]\" value=\"";
                    // line 46
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"), "html", null, true);
                    echo "\" ";
                    echo twig_escape_filter($this->env, set_checkbox("kelas_id[]", $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"), ((((!twig_test_empty($this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "kelas_id"))) && in_array($this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"), $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "kelas_id")))) ? (true) : (""))), "html", null, true);
                    echo "> ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "nama"), "html", null, true);
                    echo "
                                        </label>
                                    </li>
                                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['k'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 50
                echo "                                </ul>
                            </td>
                        </tr>
                        ";
            }
            // line 54
            echo "                        <tr>
                            <th>Tipe</th>
                            <td>
                                <ul class=\"unstyled inline\" style=\"margin-left: -5px;\">
                                    <li>
                                        <label class=\"checkbox inline\">
                                            <input type=\"checkbox\" name=\"type[]\" value=\"3\" ";
            // line 60
            echo twig_escape_filter($this->env, set_checkbox("type[]", "3", ((((!twig_test_empty($this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "type"))) && in_array("3", $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "type")))) ? (true) : (""))), "html", null, true);
            echo "> Ganda
                                        </label>
                                    </li>
                                    <li>
                                        <label class=\"checkbox inline\">
                                            <input type=\"checkbox\" name=\"type[]\" value=\"2\" ";
            // line 65
            echo twig_escape_filter($this->env, set_checkbox("type[]", "2", ((((!twig_test_empty($this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "type"))) && in_array("2", $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "type")))) ? (true) : (""))), "html", null, true);
            echo "> Essay
                                        </label>
                                    </li>
                                   <!--  <li>
                                        <label class=\"checkbox inline\">
                                            <input type=\"checkbox\" name=\"type[]\" value=\"1\" ";
            // line 70
            echo twig_escape_filter($this->env, set_checkbox("type[]", "1", ((((!twig_test_empty($this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "type"))) && in_array("1", $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "type")))) ? (true) : (""))), "html", null, true);
            echo "> Upload
                                        </label>
                                    </li> -->
                                </ul>
                            </td>
                        </tr>
                        <tr>
                            <th width=\"15%\">Judul</th>
                            <td>
                                <input type=\"text\" name=\"judul\" class=\"span4\" value=\"";
            // line 79
            echo twig_escape_filter($this->env, set_value("judul", $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "judul")), "html", null, true);
            echo "\">
                            </td>
                        </tr>
                        <tr>
                            <th>Info</th>
                            <td>
                                <input type=\"text\" name=\"info\" class=\"span5\" value=\"";
            // line 85
            echo twig_escape_filter($this->env, set_value("info", $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "info")), "html", null, true);
            echo "\">
                            </td>
                        </tr>
                        ";
            // line 88
            if ((is_pengajar() == false)) {
                // line 89
                echo "                        <tr>
                            <th>Pembuat</th>
                            <td>
                                <input type=\"text\" name=\"pembuat\" class=\"span4\" value=\"";
                // line 92
                echo twig_escape_filter($this->env, set_value("pembuat", $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "pembuat")), "html", null, true);
                echo "\">
                            </td>
                        </tr>
                        ";
            }
            // line 96
            echo "                        <tr>
                            <th>Status</th>
                            <td>
                                <ul class=\"unstyled inline\" style=\"margin-left: -5px;\">
                                    <li>
                                        <label class=\"checkbox inline\">
                                            <input type=\"checkbox\" name=\"status[]\" value=\"1\" ";
            // line 102
            echo twig_escape_filter($this->env, set_checkbox("status[]", "1", ((((!twig_test_empty($this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "status"))) && in_array("1", $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "status")))) ? (true) : (""))), "html", null, true);
            echo "> Terbit
                                        </label>
                                    </li>
                                    <li>
                                        <label class=\"checkbox inline\">
                                            <input type=\"checkbox\" name=\"status[]\" value=\"0\" ";
            // line 107
            echo twig_escape_filter($this->env, set_checkbox("status[]", "0", (((($this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "status") != "") && in_array("0", $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "status")))) ? (true) : (""))), "html", null, true);
            echo "> Tutup
                                        </label>
                                    </li>
                                </ul>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>
                                <button type=\"submit\" class=\"btn btn-info\">Filter</button>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>

        </div>
        ";
        }
        // line 125
        echo "
        <br>

        ";
        // line 128
        if ((is_siswa() == false)) {
            // line 129
            echo "        <table width=\"100%\" align=\"center\">
            <tr>
                <td align=\"center\"><div class=\"badge badge-info\">Tambah Tugas</div></td>
            </tr>
            <tr>
                <td align=\"center\">
                    <div class=\"btn-group\">
             
                            ";
            // line 137
            echo anchor("tugas/add/3", "Pilihan Ganda", array("class" => "btn btn-success"));
            echo "
                            ";
            // line 138
            echo anchor("tugas/add/2", "Essay", array("class" => "btn btn-primary"));
            echo "
                            <!-- ";
            // line 139
            echo anchor("tugas/add/1", "Upload", array("class" => "btn btn-warning"));
            echo " -->
                              
                    </div>
                </td>
            </tr>
        
        </table>
        <br><br>
        ";
        }
        // line 148
        echo "

        <!-- JIKA SISWA -->
        ";
        // line 151
        if ((is_siswa() == true)) {
            // line 152
            echo "         <table class=\"table table-striped\">
            <thead>
               
            </thead>
            <tbody>
                ";
            // line 157
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["tugas"]) ? $context["tugas"] : null));
            foreach ($context['_seq'] as $context["no"] => $context["m"]) {
                // line 158
                echo "                <tr>

                    <!-- <tr ";
                // line 160
                echo ((((is_siswa() && ($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "aktif") == 1)) && (sudah_ngerjakan($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id"), get_sess_data("user", "id")) == false))) ? ("class=\"success\"") : (""));
                echo "> -->
                   
                    <td>
                        <strong class=\"text-success\">";
                // line 163
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "judul"), "html", null, true);
                echo "</strong>
                        <br><small>Mapel: <b>";
                // line 164
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel"), "nama"), "html", null, true);
                echo "</b>,

                        ";
                // line 166
                if ((($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "type_label") == "Ganda") || ($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "type_label") == "Essay"))) {
                    // line 167
                    echo "                            , durasi: ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "durasi"), "html", null, true);
                    echo " Menit,
                        ";
                }
                // line 169
                echo "
                        dibuat oleh : <a href=\"";
                // line 170
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "pembuat"), "link_profil"), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "pembuat"), "nama"), "html", null, true);
                echo "</a></small>
                        ";
                // line 171
                if ((is_siswa() && ($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "info") != ""))) {
                    echo " |
                        <small>Tipe Tugas :</small>
                        ";
                    // line 173
                    if (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "type_label") == "Ganda")) {
                        // line 174
                        echo "                            <span class=\"label label-success\">Ganda</span>
                        ";
                    } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "type_label") == "Essay")) {
                        // line 176
                        echo "                            <span class=\"label label-info\">Essay</span>
                        ";
                    } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "type_label") == "Upload")) {
                        // line 178
                        echo "                            <span class=\"label label-warning\">Upload</span>
                        ";
                    }
                    // line 180
                    echo "                          <!--   <hr style=\"margin-top: 5px;margin-bottom: 5px;border:none;border-bottom: 1px dashed black;\">
                            ";
                    // line 181
                    echo $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "info");
                    echo " -->
                        ";
                }
                // line 183
                echo "                    </td>
                    <td>
                        <div>
                        ";
                // line 186
                if ((is_siswa() == true)) {
                    // line 187
                    echo "                            ";
                    if (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "aktif") == 1)) {
                        // line 188
                        echo "                                ";
                        if ((sudah_ngerjakan($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id"), get_sess_data("user", "id")) == false)) {
                            // line 189
                            echo "                                    ";
                            echo anchor(("tugas/kerjakan/" . $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id")), "<i class=\"icon-arrow-right\"></i> Kerjakan", array("class" => "btn btn-primary btn-small", "onclick" => "return confirm('Anda yakin ingin memulai mengerjakan tugas ini?')"));
                            echo "
                                ";
                        }
                        // line 191
                        echo "
                                ";
                        // line 192
                        if ((sudah_ngerjakan($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id"), get_sess_data("user", "id")) == true)) {
                            // line 193
                            echo "                                    <small><b>Status:</b> <span class=\"label label-info\">Dalam proses pengoreksian</span></small>
                                ";
                        }
                        // line 195
                        echo "                            ";
                    } else {
                        // line 196
                        echo "                                ";
                        echo anchor(("tugas/nilai/" . $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id")), "<i class=\"icon-flag\"></i> Lihat Nilai", array("class" => "btn btn-info btn-small iframe-lihat-nilai"));
                        echo "
                            ";
                    }
                    // line 198
                    echo "                        ";
                }
                // line 199
                echo "                        </div>
                    </td>
                </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['no'], $context['m'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 203
            echo "            </tbody>
        </table>

        <!-- JIKA ADMIN DAN GURU -->
        ";
        } else {
            // line 208
            echo "        <table class=\"table table-striped\">
            <thead>
                <tr>
                    <th width=\"7%\">ID</th>
                    <th>Informasi Tugas</th>
                </tr>
            </thead>
            <tbody>
                ";
            // line 216
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["tugas"]) ? $context["tugas"] : null));
            foreach ($context['_seq'] as $context["no"] => $context["m"]) {
                // line 217
                echo "                <tr ";
                echo ((((is_siswa() && ($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "aktif") == 1)) && (sudah_ngerjakan($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id"), get_sess_data("user", "id")) == false))) ? ("class=\"success\"") : (""));
                echo ">
                    <td><b>";
                // line 218
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id"), "html", null, true);
                echo "</b></td>
                    <td>
                        ";
                // line 220
                if (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "aktif") == 0)) {
                    // line 221
                    echo "                        <strong style=\"color: grey\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "judul"), "html", null, true);
                    echo "</strong>

                        <span class=\"badge badge-default\">Ditutup</span>

                        ";
                } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "aktif") == 1)) {
                    // line 226
                    echo "                        <strong style=\"color: green\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "judul"), "html", null, true);
                    echo "</strong>
                            <span class=\"badge badge-success\">Dibuka</span>
                        ";
                }
                // line 229
                echo "
                        <br><small><b>";
                // line 230
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel"), "nama"), "html", null, true);
                echo "</b>

                        ";
                // line 232
                $context['_parent'] = (array) $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "tugas_kelas"));
                foreach ($context['_seq'] as $context["_key"] => $context["mk"]) {
                    // line 233
                    echo "                            , ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["mk"]) ? $context["mk"] : null), "nama"), "html", null, true);
                    echo "
                        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['mk'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 235
                echo "
                        ";
                // line 236
                if ((($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "type_label") == "Ganda") || ($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "type_label") == "Essay"))) {
                    // line 237
                    echo "                            , durasi: ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "durasi"), "html", null, true);
                    echo " Menit ,
                        ";
                }
                // line 239
                echo "
                       , <b>Pembuat : </b> <a href=\"";
                // line 240
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "pembuat"), "link_profil"), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "pembuat"), "nama"), "html", null, true);
                echo "</a>, ";
                echo twig_escape_filter($this->env, tgl_jam_indo($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "tgl_buat")), "html", null, true);
                echo "</small>
                        <!-- ";
                // line 241
                if ((is_siswa() && ($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "info") != ""))) {
                    // line 242
                    echo "                            <hr style=\"margin-top: 5px;margin-bottom: 5px;border:none;border-bottom: 1px dashed black;\">
                            ";
                    // line 243
                    echo $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "info");
                    echo "
                        ";
                }
                // line 244
                echo " -->

                        ";
                // line 246
                if (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "type_label") == "Ganda")) {
                    // line 247
                    echo "                            <span><b style=\"color: green\">Ganda</b></span>
                        ";
                } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "type_label") == "Essay")) {
                    // line 249
                    echo "                            <span><b style=\"color: blue\">Essay</b></span>
                        ";
                } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "type_label") == "Upload")) {
                    // line 251
                    echo "                            <span><b style=\"color: orange\">Upload</b></span>
                        ";
                }
                // line 253
                echo "

                    <!--     <hr style=\"border: 1px dashed grey\"> -->

                     ";
                // line 257
                if ((is_siswa() == false)) {
                    // line 258
                    echo "                   
                        
                            <ul class=\"nav\">
                                <li class=\"nav-user dropdown\"><a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">
                                <b class=\"caret\"></b>
                            </a>
                                
                                <ul class=\"dropdown-menu\">
                                    

                                    ";
                    // line 268
                    if ((($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "type_label") == "Ganda") || ($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "type_label") == "Essay"))) {
                        // line 269
                        echo "                                        <li>";
                        echo anchor(("tugas/manajemen_soal/" . $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id")), "<i class=\"icon-tasks\"></i> Soal");
                        echo "</li>
                                    ";
                    }
                    // line 271
                    echo "

                                    ";
                    // line 273
                    if (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "aktif") == 0)) {
                        // line 274
                        echo "                                        <li>";
                        echo anchor(((("tugas/terbitkan/" . $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id")) . "/") . enurl_redirect(current_url())), "<i class=\"icon-check\"></i> Terbitkan");
                        echo "</li>
                                    ";
                    } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "aktif") == 1)) {
                        // line 276
                        echo "                                        <li>";
                        echo anchor(((("tugas/tutup/" . $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id")) . "/") . enurl_redirect(current_url())), "<i class=\"icon-minus\"></i> Tutup");
                        echo "</li>
                                    ";
                    }
                    // line 278
                    echo "
                                    <li>";
                    // line 279
                    echo anchor(((("tugas/edit/" . $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id")) . "/") . enurl_redirect(current_url())), "<i class=\"icon-edit\"></i> Edit");
                    echo "</li>

                                    ";
                    // line 281
                    if (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "type_id") == 3)) {
                        // line 282
                        echo "                                        <li>";
                        echo anchor(("tugas/nilai/" . $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id")), "<i class=\"icon-flag\"></i> Nilai");
                        echo "</li>
                                    ";
                    } else {
                        // line 284
                        echo "                                        <li>";
                        echo anchor(("tugas/koreksi/" . $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id")), "<i class=\"icon-list\"></i> Koreksi");
                        echo "</li>
                                    ";
                    }
                    // line 286
                    echo "                                    
                                </ul>
                            </li>
                            </ul>
              
                        ";
                }
                // line 292
                echo "

                    </td>

                    
                    
                </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['no'], $context['m'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 300
            echo "            </tbody>
        </table>
        ";
        }
        // line 303
        echo "       
        <br>
        ";
        // line 305
        echo (isset($context["pagination"]) ? $context["pagination"] : null);
        echo "

    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "list-tugas.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  623 => 305,  619 => 303,  614 => 300,  601 => 292,  593 => 286,  587 => 284,  581 => 282,  579 => 281,  574 => 279,  571 => 278,  565 => 276,  559 => 274,  557 => 273,  553 => 271,  547 => 269,  545 => 268,  533 => 258,  531 => 257,  525 => 253,  521 => 251,  517 => 249,  513 => 247,  511 => 246,  507 => 244,  502 => 243,  499 => 242,  497 => 241,  489 => 240,  486 => 239,  480 => 237,  478 => 236,  475 => 235,  466 => 233,  462 => 232,  457 => 230,  454 => 229,  447 => 226,  438 => 221,  436 => 220,  431 => 218,  426 => 217,  422 => 216,  412 => 208,  405 => 203,  396 => 199,  393 => 198,  387 => 196,  384 => 195,  380 => 193,  378 => 192,  375 => 191,  369 => 189,  366 => 188,  363 => 187,  361 => 186,  356 => 183,  351 => 181,  348 => 180,  344 => 178,  340 => 176,  336 => 174,  334 => 173,  329 => 171,  323 => 170,  320 => 169,  314 => 167,  312 => 166,  307 => 164,  303 => 163,  297 => 160,  293 => 158,  289 => 157,  282 => 152,  280 => 151,  275 => 148,  263 => 139,  259 => 138,  255 => 137,  245 => 129,  243 => 128,  238 => 125,  217 => 107,  209 => 102,  201 => 96,  194 => 92,  189 => 89,  187 => 88,  181 => 85,  172 => 79,  160 => 70,  152 => 65,  144 => 60,  136 => 54,  130 => 50,  116 => 46,  112 => 44,  108 => 43,  102 => 39,  100 => 38,  95 => 35,  81 => 31,  77 => 29,  73 => 28,  64 => 22,  56 => 16,  54 => 15,  49 => 13,  42 => 8,  39 => 7,  32 => 4,  29 => 3,);
    }
}

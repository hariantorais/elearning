<?php

/* welcome.html */
class __TwigTemplate_eac5bd087f7d7ce830ba114e3d5059d5d345ccf707b1b3ae165ebebcc76f7e21 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-private.html");

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-private.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "

<div class=\"btn-controls\">
    <div id=\"show-urgent-info\"></div>

    <div class=\"btn-box-row row-fluid\">
        <div class=\"span12\">
            <table class=\"visible-phone visible-tablet\">
                <tr>
                    <td><img src=\"";
        // line 13
        echo twig_escape_filter($this->env, get_url_image_session(get_sess_data("user", "foto"), "medium", get_sess_data("user", "jenis_kelamin")), "html", null, true);
        echo "\" class=\"nav-avatar-welcome img-polaroid\" />
                    </td>
                    <td width=\"70%\">
                                <span style=\"color: black\";>Assalamu'alaikum</span>, <b>";
        // line 16
        echo twig_escape_filter($this->env, get_sess_data("user", "nama"), "html", null, true);
        echo "</b> <br>
                                ";
        // line 17
        if (is_siswa()) {
            echo "                                
                                Kelas ";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["pengguna"]) ? $context["pengguna"] : null), "nama_kelas"), "html", null, true);
            echo "
                                ";
        }
        // line 20
        echo "                                ";
        if (is_pengajar()) {
            echo "                                
                                Pengajar
                                ";
        }
        // line 23
        echo "                                ";
        if (is_admin()) {
            echo "                                
                                Pengajar | <span class=\"badge badge-warning\">Administrator</span>
                                ";
        }
        // line 26
        echo "                    </td>
                    <td width=\"5%\" align=\"right\">
                        ";
        // line 28
        if (is_admin()) {
            // line 29
            echo "                        ";
            echo anchor(((("pengajar/detail/" . get_sess_data("user", "status_id")) . "/") . get_sess_data("user", "id")), "<i style=\"font-size: 16px; color: grey\" class=\"icon-edit\"></i>", array("title" => "Detail Profil"));
            echo "
                        ";
        }
        // line 31
        echo "
                        ";
        // line 32
        if (is_pengajar()) {
            // line 33
            echo "                        ";
            echo anchor("login/pp", "<i style=\"font-size: 16px; color: grey\" class=\"icon-edit\"></i>");
            echo "
                        ";
        }
        // line 35
        echo "
                        ";
        // line 36
        if (is_siswa()) {
            // line 37
            echo "                        ";
            echo anchor("login/pp", "<i style=\"font-size: 16px; color: grey\" class=\"icon-edit\"></i>");
            echo "
                        ";
        }
        // line 39
        echo "                    </td>
                </tr>
            </table>
            <div class=\"visible-tablet visible-phone\">
                <br><br>
            </div>
            <li class=\"nav-user dropdown visible-phone\">
                <ul class=\"dropdown-menu\">
                    ";
        // line 47
        if (is_admin()) {
            // line 48
            echo "                    <li>";
            echo anchor(((("pengajar/detail/" . get_sess_data("user", "status_id")) . "/") . get_sess_data("user", "id")), "Detail Profil", array("title" => "Detail Profil"));
            echo "</li>
                    ";
        }
        // line 50
        echo "
                    ";
        // line 51
        if (is_pengajar()) {
            // line 52
            echo "                    <li>";
            echo anchor("login/pp", "Profil & Akun Login");
            echo "</li>
                    ";
        }
        // line 54
        echo "
                    ";
        // line 55
        if (is_siswa()) {
            // line 56
            echo "                    <li>";
            echo anchor("login/pp", "Profil & Akun Login");
            echo "</li>
                    ";
        }
        // line 58
        echo "
                    <li><a href=\"";
        // line 59
        echo twig_escape_filter($this->env, site_url(("login/login_log/" . get_sess_data("login", "id"))), "html", null, true);
        echo "\">Login log</a></li>
                    <li><a href=\"";
        // line 60
        echo twig_escape_filter($this->env, site_url("login/logout"), "html", null, true);
        echo "\">Logout</a></li>
                </ul>
            </li>
            
        </div>
    </div>

    ";
        // line 67
        if (is_admin()) {
            // line 68
            echo "    ";
            if (((isset($context["count_mapel_kelas"]) ? $context["count_mapel_kelas"] : null) == 0)) {
                // line 69
                echo "    <div class=\"well well-large well-box\" style=\"border:2px solid #29b7d3;\">
        <b><i class=\"icon-wrench\"></i> Atur data berikut supaya aplikasi e-learing dapat berjalan dengan baik:</b>
        <table class=\"table table-hover\" style=\"margin-top:10px;\">
            <tr>
                <td width=\"30%\">
                    <a href=\"";
                // line 74
                echo twig_escape_filter($this->env, site_url("mapel"), "html", null, true);
                echo "\"><b><i class=\"menu-icon icon-book\"></i> Manajemen Matapelajaran</b></a>
                </td>
                <td>
                    Input semua Matapelajaran yang ada di sekolah
                </td>
            </tr>
            <tr>
                <td width=\"30%\">
                    <a href=\"";
                // line 82
                echo twig_escape_filter($this->env, site_url("kelas"), "html", null, true);
                echo "\"><b><i class=\"menu-icon icon-tasks\"></i> Manajemen Kelas</b></a>
                </td>
                <td>
                    Input semua Kelas yang ada di sekolah
                </td>
            </tr>
            <tr>
                <td width=\"30%\">
                    <a href=\"";
                // line 90
                echo twig_escape_filter($this->env, site_url("kelas/mapel_kelas"), "html", null, true);
                echo "\"><b><i class=\"menu-icon icon-paste\"></i> Matapelajaran Kelas</b></a>
                </td>
                <td>
                    Atur Matapelajaran pada tiap-tiap Kelas
                </td>
            </tr>
        </table>
    </div>
    ";
            }
            // line 99
            echo "
    <table width=\"100%\" class=\"visible-phone\">
        <tr>
            <td width=\"33%\" align=\"center\">
                <a href=\"";
            // line 103
            echo twig_escape_filter($this->env, site_url("siswa/index/1"), "html", null, true);
            echo "\" class=\"btn-box big span2\">
                    <i class=\"icon-group\"></i>
                    <!-- <b>";
            // line 105
            echo twig_escape_filter($this->env, (isset($context["jml_siswa"]) ? $context["jml_siswa"] : null), "html", null, true);
            echo "</b> -->
                    <p><span class=\"badge\" style=\"background-color: blue; color: white\">Siswa</span><span class=\"menu-count-pending-siswa2\"></span></p>
                </a>
            </td>
            <td width=\"33%\" align=\"center\">
                 <a href=\"";
            // line 110
            echo twig_escape_filter($this->env, site_url("pengajar/index/1"), "html", null, true);
            echo "\" class=\"btn-box big span2\">
                    <i class=\"icon-user\"></i>
                    <!-- <b>";
            // line 112
            echo twig_escape_filter($this->env, (isset($context["jml_pengajar"]) ? $context["jml_pengajar"] : null), "html", null, true);
            echo "</b> -->
                    <p><span class=\"badge\" style=\"background-color: blue; color: white\">Guru</span><span class=\"menu-count-pending-pengajar2\"></span></p>
                </a>
            </td>
            <td width=\"33%\" align=\"center\">
                <a href=\"";
            // line 117
            echo twig_escape_filter($this->env, site_url("message"), "html", null, true);
            echo "\" class=\"btn-box big span2\">
                    <i class=\"icon-comments\"></i>
                    <p><span class=\"badge\" style=\"background-color: blue; color: white\">Pesan</span><span class=\"menu-count-new-msg2\"></span></p>
                </a>
            </td>
            
        </tr>
    </table>
    <table width=\"100%\" class=\"visible-phone\">
        <tr>
            <td width=\"33%\" align=\"center\">
                <a href=\"";
            // line 128
            echo twig_escape_filter($this->env, site_url("materi?clear_filter=true"), "html", null, true);
            echo "\" class=\"btn-box big span2\">
                    <i class=\"icon-book\"></i>
                    <p><span class=\"badge\" style=\"background-color: blue; color: white\">Materi</p>
                </a>
            </td>
            <td width=\"33%\" align=\"center\">
                <a href=\"";
            // line 134
            echo twig_escape_filter($this->env, site_url("tugas?clear_filter=true"), "html", null, true);
            echo "\" class=\"btn-box big span2\">
                    <i class=\"icon-tasks\"></i>
                    <p><span class=\"badge\" style=\"background-color: blue; color: white\">Tugas</p>
                </a>
            </td>
            
            <td width=\"33%\" align=\"center\">
                <a href=\"";
            // line 141
            echo twig_escape_filter($this->env, site_url("pengumuman"), "html", null, true);
            echo "\" class=\"btn-box big span2\">
                    <i class=\"icon-bullhorn\"></i>
                    <p><span class=\"badge\" style=\"background-color: blue; color: white\">Pengumuman</p>
                </a>
            </td>
        </tr>
    </table>

    

    <div class=\"btn-box-row row-fluid\">
        <div class=\"span6\">
              <div class=\"module\">
                <div class=\"module-head\" style=\"background-color: white\">
                    <span class=\"badge\" style=\"background-color: orange; color: white\"><i class=\"icon-bullhorn\"></i> Pengumuman</span>
                </div>
                <div class=\"module-body\">
                    <table class=\"table table-striped table-condensed\">
                                ";
            // line 159
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["pengumuman"]) ? $context["pengumuman"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
                // line 160
                echo "                                <tr>
                                    <td>";
                // line 161
                echo anchor(("pengumuman/detail/" . $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id")), $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "judul"));
                echo "</td>
                                </tr>
                                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 164
            echo "                    </table>
                </div>
              </div>

              <div class=\"module\">
                <div class=\"module-head\" style=\"background-color: white\">
                    <span class=\"badge\" style=\"background-color: salmon; color: white\"><i class=\"icon-signin\"></i> Riwayat Login User</span>
                </div>
                <div class=\"module-body\">
                    <div id=\"show-last-login-list\"></div>
                </div>
              </div>

        </div>
    </div>
    ";
        }
        // line 180
        echo "
    ";
        // line 181
        if (is_pengajar()) {
            // line 182
            echo "    ";
            $context["peraturan"] = get_pengaturan("peraturan-elearning", "value");
            // line 183
            echo "    ";
            if ((!twig_test_empty((isset($context["peraturan"]) ? $context["peraturan"] : null)))) {
                // line 184
                echo "    <div class=\"btn-box-row row-fluid\">
         <div class=\"span12\">
            <div class=\"well well-small well-box\">
                <b>Peraturan e-learning : </b><br>
                ";
                // line 188
                echo (isset($context["peraturan"]) ? $context["peraturan"] : null);
                echo "
            </div>
         </div>
    </div>
    ";
            }
            // line 193
            echo "
    <table width=\"100%\">
        <tr>
            <td width=\"20%\" align=\"center\">
                <a href=\"";
            // line 197
            echo twig_escape_filter($this->env, site_url("materi?clear_filter=true"), "html", null, true);
            echo "\" class=\"btn-box big span2\">
                    <i class=\"icon-book\"></i>
                   <p><span class=\"badge\" style=\"background-color: blue; color: white\">Materi</p>
                </a>
            </td>
            <td width=\"20%\" align=\"center\">
                <a href=\"";
            // line 203
            echo twig_escape_filter($this->env, site_url("tugas?clear_filter=true"), "html", null, true);
            echo "\" class=\"btn-box big span2\">
                    <i class=\"icon-tasks\"></i>
                    <p><span class=\"badge\" style=\"background-color: blue; color: white\">Tugas</p>
                </a>
            </td>
            <td width=\"20%\" align=\"center\">
                <a href=\"";
            // line 209
            echo twig_escape_filter($this->env, site_url("message"), "html", null, true);
            echo "\" class=\"btn-box big span2\">
                    <i class=\"icon-comments\"></i>
                  <p><span class=\"badge\" style=\"background-color: blue; color: white\">Pesan</span><span class=\"menu-count-new-msg2\"></span></p>
                </a>
            </td>
            <td width=\"20%\" align=\"center\">
                <a href=\"";
            // line 215
            echo twig_escape_filter($this->env, site_url("pengajar/jadwal"), "html", null, true);
            echo "\" class=\"btn-box big span2\">
                    <i class=\"icon-calendar\"></i>
                    <p><span class=\"badge\" style=\"background-color: blue; color: white\">Jadwal</p>
                </a>
            </td>
        </tr>
    </table>

    <div class=\"btn-box-row row-fluid\">
        <div class=\"span6\">

            <div class=\"module\">
                <div class=\"module-head\" style=\"background-color: white\">
                    <span class=\"badge\" style=\"background-color: orange; color: white\"><i class=\"icon-bullhorn\"></i> Pengumuman</span>
                </div>
                <div class=\"module-body\">
                    <table class=\"table table-striped table-condensed\">
                    ";
            // line 232
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["pengumuman"]) ? $context["pengumuman"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
                // line 233
                echo "                    <tr>
                        <td>";
                // line 234
                echo anchor(("pengumuman/detail/" . $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id")), $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "judul"));
                echo "</td>
                    </tr>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 237
            echo "                </table>
                </div>
            </div>

        </div>
    </div>
    ";
        }
        // line 244
        echo "
    ";
        // line 245
        if (is_siswa()) {
            // line 246
            echo "    ";
            $context["peraturan"] = get_pengaturan("peraturan-elearning", "value");
            // line 247
            echo "    ";
            if ((!twig_test_empty((isset($context["peraturan"]) ? $context["peraturan"] : null)))) {
                // line 248
                echo "    <div class=\"btn-box-row row-fluid\">
         <div class=\"span12\">
            <div class=\"well well-small well-box\">
                <b>Peraturan e-learning : </b><br>
                ";
                // line 252
                echo (isset($context["peraturan"]) ? $context["peraturan"] : null);
                echo "
            </div>
         </div>
    </div>
    ";
            }
            // line 257
            echo "
    <!-- <table width=\"100%\">
        <tr>
            <td width=\"20%\" height=\"20%\" align=\"center\">
                <a href=\"";
            // line 261
            echo twig_escape_filter($this->env, site_url("materi?clear_filter=true"), "html", null, true);
            echo "\" class=\"btn-box big span2\">
                    <i class=\"icon-book\"></i>
                    <p><span class=\"badge\" style=\"background-color: blue; color: white\">Materi</p>
                </a>
            </td>
            <td width=\"20%\" align=\"center\">
                <a href=\"";
            // line 267
            echo twig_escape_filter($this->env, site_url("tugas/daftar_tugas"), "html", null, true);
            echo "\" class=\"btn-box big span2\">
                    <i class=\"icon-tasks\"></i>
                     <p><span class=\"badge\" style=\"background-color: blue; color: white\">Tugas</p>
                </a>
            </td>
            <td width=\"20%\" align=\"center\">
                <a href=\"";
            // line 273
            echo twig_escape_filter($this->env, site_url("message"), "html", null, true);
            echo "\" class=\"btn-box big span2\">
                    <i class=\"icon-comments\"></i>
                    <p><span class=\"badge\" style=\"background-color: blue; color: white\">Pesan</span><span class=\"menu-count-new-msg2\"></span></p>
                </a>
            </td>
            <td width=\"20%\" align=\"center\">
                <a href=\"";
            // line 279
            echo twig_escape_filter($this->env, site_url("siswa/jadwal_mapel"), "html", null, true);
            echo "\" class=\"btn-box big span2\">
                    <i class=\"icon-calendar\"></i>
                     <p><span class=\"badge\" style=\"background-color: blue; color: white\">Jadwal</p>
                </a>
            </td>
        </tr>
    </table> -->


    

    <div class=\"btn-box-row row-fluid\">
        <!-- <div class=\"span6\">

            <div class=\"module\">
                <div class=\"module-head\" style=\"background-color: white\">
                    <span class=\"badge\" style=\"background-color: orange; color: white\"><i class=\"icon-bullhorn\"></i> Pengumuman</span>
                </div>
                <div class=\"module-body\">
                   <table class=\"table table-striped table-condensed\">
                    ";
            // line 299
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["pengumuman"]) ? $context["pengumuman"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
                // line 300
                echo "                    <tr>
                        <td>";
                // line 301
                echo anchor(("pengumuman/detail/" . $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id")), $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "judul"));
                echo "</td>
                    </tr>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 304
            echo "                </table>
                </div>
            </div>

            <div class=\"well well-small well-box\">
                <center><b>Himbauan Mudir Kepada Wali Santri</b></center>
                <center></center>
                   <iframe width=\"100%\" height=\"100%\" src=\"https://www.youtube.com/embed/_aq3F_v-x_M\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>
            </div>
        </div> -->

        <div class=\"span8\" style=\"font-family: roboto; font-size: 14pt\">
            <!-- <div class=\"module\">
               <div class=\"module-head\" style=\"background-color: white\">
                    <span class=\"badge\" style=\"background-color: salmon; color: white\"><i class=\"icon-book\"></i> Materi Terbaru</span>
                </div>
                <div class=\"module-body\">
                    <table class=\"table table-striped table-condensed\">
                    ";
            // line 322
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["materi_terbaru"]) ? $context["materi_terbaru"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["m"]) {
                // line 323
                echo "                    <tr>
                        <td>
                            
                            <a href=\"";
                // line 326
                echo twig_escape_filter($this->env, site_url(("materi/detail/" . $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id"))), "html", null, true);
                echo "\" target=\"_tab\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "judul"), "html", null, true);
                echo "</a>
                        </td>
                        <td>";
                // line 328
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "absen_siswa"), "absen"), "html", null, true);
                echo "</td>
                        <td>
                            
                            ";
                // line 331
                if (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 1)) {
                    // line 332
                    echo "                            BHS. INDONESIA
                            ";
                } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 2)) {
                    // line 334
                    echo "                            BHS. INGGRIS
                            ";
                } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 3)) {
                    // line 336
                    echo "                            MATEMATIKA
                            ";
                } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 4)) {
                    // line 338
                    echo "                            PENJASKES
                            ";
                } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 5)) {
                    // line 340
                    echo "                            PAI
                            ";
                } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 6)) {
                    // line 342
                    echo "                            PPKn
                            ";
                } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 7)) {
                    // line 344
                    echo "                            IPA
                            ";
                } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 8)) {
                    // line 346
                    echo "                            IPS
                            ";
                } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 9)) {
                    // line 348
                    echo "                            PRAKARYA
                            ";
                } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 10)) {
                    // line 350
                    echo "                            SENI BUDAYA
                            ";
                } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 11)) {
                    // line 352
                    echo "                            AQIDAH
                            ";
                } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 12)) {
                    // line 354
                    echo "                            FIQIH
                            ";
                } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 13)) {
                    // line 356
                    echo "                            BAHASA ARAB
                            ";
                } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 14)) {
                    // line 358
                    echo "                            DO'A & DZIKIR
                            ";
                } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 15)) {
                    // line 360
                    echo "                            KHOT IMLA'
                            ";
                } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 16)) {
                    // line 362
                    echo "                            NAHWU
                            ";
                } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 17)) {
                    // line 364
                    echo "                            SHOROF
                            ";
                } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 19)) {
                    // line 366
                    echo "                            TAJWID
                            ";
                }
                // line 368
                echo "                            
                        </td>
                    </tr>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['m'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 372
            echo "                </table>
                </div>
              </div> -->

            <div class=\"module\">
                <div class=\"module-head\" style=\"background-color: white\">
                    <span class=\"badge\" style=\"background-color: mediumaquamarine; color: white\"><i class=\"icon-tasks\"></i> Ujian Belum Dikerjakan</span>
                </div>
                <div class=\"module-body\">
                    <table class=\"table table-striped table-condensed\">
                    ";
            // line 382
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["tugas_terbaru"]) ? $context["tugas_terbaru"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["m"]) {
                // line 383
                echo "                    ";
                if ((sudah_ngerjakan($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id"), get_sess_data("user", "id")) == false)) {
                    // line 384
                    echo "                    <tr>
                        <td>
                            <b><a href=\"";
                    // line 386
                    echo twig_escape_filter($this->env, site_url(("tugas?judul=" . urlencode($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "judul")))), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "judul"), "html", null, true);
                    echo "</a> </b>
                        </td>
                        <td><b>
                            ";
                    // line 389
                    if (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 1)) {
                        // line 390
                        echo "                            BHS. INDONESIA
                            ";
                    } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 2)) {
                        // line 392
                        echo "                            BHS. INGGRIS
                            ";
                    } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 3)) {
                        // line 394
                        echo "                            MATEMATIKA
                            ";
                    } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 4)) {
                        // line 396
                        echo "                            PENJASKES
                            ";
                    } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 5)) {
                        // line 398
                        echo "                            PAI
                            ";
                    } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 6)) {
                        // line 400
                        echo "                            PPKn
                            ";
                    } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 7)) {
                        // line 402
                        echo "                            IPA
                            ";
                    } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 8)) {
                        // line 404
                        echo "                            IPS
                            ";
                    } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 9)) {
                        // line 406
                        echo "                            PRAKARYA
                            ";
                    } elseif (($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "mapel_id") == 10)) {
                        // line 408
                        echo "                            SENI BUDAYA
                            ";
                    }
                    // line 410
                    echo "                            </b>
                        </td>
                       
                    </tr>
                    ";
                }
                // line 415
                echo "                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['m'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 416
            echo "                </table>
                </div>
              </div>

              <div class=\"module\">
                <div class=\"module-head\" style=\"background-color: white\">
                    <span class=\"badge\" style=\"background-color: darkblue; color: white\"><i class=\"icon-tasks\"></i> Hasil Ujian</span>
                </div>
                <div class=\"module-body\">
                    <table class=\"table table-striped table-condensed\">
                    ";
            // line 426
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["tugas_selesai"]) ? $context["tugas_selesai"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["m"]) {
                // line 427
                echo "                  
                    <tr>
                        <td>
                            <b>";
                // line 430
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "judul"), "html", null, true);
                echo "</b>
                        </td>
                        <td>
                            <span class=\"badge\" style=\"font-size: 20px; background-color: teal\">";
                // line 433
                echo twig_escape_filter($this->env, round($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "nilai")), "html", null, true);
                echo "</span>
                        </td>
                       
                    </tr>
                    
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['m'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 439
            echo "                </table>
                </div>
              </div>

          </div>

            

           


    </div>
    ";
        }
        // line 452
        echo "
    

    
</div>

";
    }

    public function getTemplateName()
    {
        return "welcome.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  797 => 452,  782 => 439,  770 => 433,  764 => 430,  759 => 427,  755 => 426,  743 => 416,  737 => 415,  730 => 410,  726 => 408,  722 => 406,  718 => 404,  714 => 402,  710 => 400,  706 => 398,  702 => 396,  698 => 394,  694 => 392,  690 => 390,  688 => 389,  680 => 386,  676 => 384,  673 => 383,  669 => 382,  657 => 372,  648 => 368,  644 => 366,  640 => 364,  636 => 362,  632 => 360,  628 => 358,  624 => 356,  620 => 354,  616 => 352,  612 => 350,  608 => 348,  604 => 346,  600 => 344,  596 => 342,  592 => 340,  588 => 338,  584 => 336,  580 => 334,  576 => 332,  574 => 331,  568 => 328,  561 => 326,  556 => 323,  552 => 322,  532 => 304,  523 => 301,  520 => 300,  516 => 299,  493 => 279,  484 => 273,  475 => 267,  466 => 261,  460 => 257,  452 => 252,  446 => 248,  443 => 247,  440 => 246,  438 => 245,  435 => 244,  426 => 237,  417 => 234,  414 => 233,  410 => 232,  390 => 215,  381 => 209,  372 => 203,  363 => 197,  357 => 193,  349 => 188,  343 => 184,  340 => 183,  337 => 182,  335 => 181,  332 => 180,  314 => 164,  305 => 161,  302 => 160,  298 => 159,  277 => 141,  267 => 134,  258 => 128,  244 => 117,  236 => 112,  231 => 110,  223 => 105,  218 => 103,  212 => 99,  200 => 90,  189 => 82,  178 => 74,  171 => 69,  168 => 68,  166 => 67,  156 => 60,  152 => 59,  149 => 58,  143 => 56,  141 => 55,  138 => 54,  132 => 52,  130 => 51,  127 => 50,  121 => 48,  119 => 47,  109 => 39,  103 => 37,  101 => 36,  98 => 35,  92 => 33,  90 => 32,  87 => 31,  81 => 29,  79 => 28,  75 => 26,  68 => 23,  61 => 20,  56 => 18,  52 => 17,  48 => 16,  42 => 13,  31 => 4,  28 => 3,);
    }
}

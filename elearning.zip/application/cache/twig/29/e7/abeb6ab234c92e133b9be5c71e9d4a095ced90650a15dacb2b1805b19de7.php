<?php

/* detail-materi.html */
class __TwigTemplate_29e7abeb6ab234c92e133b9be5c71e9d4a095ced90650a15dacb2b1805b19de7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-private.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-private.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "judul"), "html", null, true);
        echo " - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "<div class=\"module\">
    <div class=\"module-head\">
        ";
        // line 10
        if (((isset($context["type"]) ? $context["type"] : null) == "tertulis")) {
            // line 11
            echo "        <form method=\"post\" action=\"";
            echo twig_escape_filter($this->env, site_url("materi/print"), "html", null, true);
            echo "\" target=\"_blank\">
            <input type=\"hidden\" name=\"materi_id\" value=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "id"), "html", null, true);
            echo "\">
            <input type=\"hidden\" name=\"type\" value=\"";
            // line 13
            echo twig_escape_filter($this->env, (isset($context["type"]) ? $context["type"] : null), "html", null, true);
            echo "\">
            <button class=\"btn btn-info pull-right btn-xs\"><i class=\"icon-print\"></i> Print</button>
        </form>
        ";
        }
        // line 17
        echo "
        
        <h3>";
        // line 19
        echo anchor("materi", "Materi");
        echo " / Detail Materi</h3>
    </div>
    <div class=\"module-body\">
        <center><span style=\"font-size: 25px; color: black\">";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "judul"), "html", null, true);
        echo "</span></center>
        ";
        // line 23
        if ((!array_key_exists("error", $context))) {
            // line 24
            echo "        <center><ul class=\"unstyled inline ul-top\">
            <li><b>";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "mapel"), "nama"), "html", null, true);
            echo "</b>,</li>
            ";
            // line 26
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "materi_kelas"));
            foreach ($context['_seq'] as $context["_key"] => $context["mk"]) {
                // line 27
                echo "                <li>";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["mk"]) ? $context["mk"] : null), "nama"), "html", null, true);
                echo ",</li>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['mk'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 29
            echo "            <li>Diposting oleh <a href=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "pembuat"), "link_profil"), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "pembuat"), "nama"), "html", null, true);
            echo "</a></li>
            <li>";
            // line 30
            echo twig_escape_filter($this->env, tgl_jam_indo($this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "tgl_posting")), "html", null, true);
            echo ",</li>
            <li>";
            // line 31
            echo ((((isset($context["type"]) ? $context["type"] : null) == "tertulis")) ? ("Dibaca") : ("Diunduh"));
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "views"), "html", null, true);
            echo " Kali</li>
            <li>";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "jml_komentar"), "html", null, true);
            echo " Komentar</li>
        </ul></center>
        ";
        }
        // line 34
        echo "<hr style=\"border: 1px solid black\">


                    ";
        // line 37
        if ((is_siswa() == true)) {
            // line 38
            echo "                        ";
            if ((($this->getAttribute((isset($context["absen"]) ? $context["absen"] : null), "siswa_id") == get_sess_data("user", "id")) && ($this->getAttribute((isset($context["absen"]) ? $context["absen"] : null), "absen") == 1))) {
                // line 39
                echo "                        <div class=\"komentar\" style=\"background-color: lightgreen\">
                        <center>
                        <p style=\"color: darkgreen;\">Anda sudah mengisi daftar hadir pada mapel ini.</p>
                        </center>
                        </div>
                        
                        ";
            } else {
                // line 46
                echo "                        <div class=\"komentar\" style=\"background-color: mistyrose\">
                            <center>
                        <p><b><u>Perhatian!</u></b><br>
                        Anda belum mengisi daftar hadir, silahkan klik tombol berwarna merah di bawah ini!</p>
                        <form method=\"post\" action=\"";
                // line 50
                echo twig_escape_filter($this->env, site_url(("materi/hadir/" . $this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "id"))), "html", null, true);
                echo "\">
                            <input type=\"hidden\" name=\"materi_id\" value=\"";
                // line 51
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "id"), "html", null, true);
                echo "\">
                            <input type=\"hidden\" name=\"siswa_id\" value=\"";
                // line 52
                echo twig_escape_filter($this->env, get_sess_data("user", "id"), "html", null, true);
                echo "\">
                            <button class=\"btn btn-danger\"><i class=\"icon-pencil\"></i>Isi Daftar Hadir</button>
                        </form>
                        </center>
                        </div>
                        ";
            }
            // line 58
            echo "                    ";
        }
        // line 59
        echo "                 
                    <hr>

        
        <div class=\"wrap-content\">
            <div class=\"content\" style=\"color: black\">
                ";
        // line 65
        if ((!array_key_exists("error", $context))) {
            // line 66
            echo "                    ";
            if (((isset($context["type"]) ? $context["type"] : null) == "tertulis")) {
                // line 67
                echo "                        ";
                echo $this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "konten");
                echo "
                    ";
            } elseif (((isset($context["type"]) ? $context["type"] : null) == "file")) {
                // line 69
                echo "                        <dl class=\"dl-horizontal\">
                            <dt>Info File</dt>
                            <dd>";
                // line 71
                echo twig_escape_filter($this->env, ((twig_test_empty($this->getAttribute($this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "file_info"), "name"))) ? ("tidak ada") : ($this->getAttribute($this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "file_info"), "name"))), "html", null, true);
                echo "</dd>
                            <dt>Ukuran</dt>
                            <dd>";
                // line 73
                echo twig_escape_filter($this->env, byte_format($this->getAttribute($this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "file_info"), "size")), "html", null, true);
                echo "</dd>
                            <dt>Diupload</dt>
                            <dd>";
                // line 75
                echo twig_escape_filter($this->env, tgl_jam_indo(mdate("%Y-%m-%d %H:%i:%s", $this->getAttribute((isset($context["materifile_info"]) ? $context["materifile_info"] : null), "date"))), "html", null, true);
                echo "</dd>
                            <dt>Format</dt>
                            <dd>";
                // line 77
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "file_info"), "mime"), "html", null, true);
                echo "</dd>
                            <dt></dt>
                            <!--<video width=\"430px\" height=\"350px\" controls>-->
                            <!--        <source src=\"";
                // line 80
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "download_link"), "html", null, true);
                echo "\" type=\"video/mp4\">-->
                            <!--            <source src=\"";
                // line 81
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "download_link"), "html", null, true);
                echo "\" type=\"audio/mp3\">-->
                            <!--</video>-->
                            <dd><br><a href=\"";
                // line 83
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "download_link"), "html", null, true);
                echo "\" class=\"btn btn-success\"><i class=\"icon-download\"></i> Download File</a></dd>
                        </dl>
                    ";
            }
            // line 86
            echo "                    
                 
                    <hr>


                    <div class=\"row-fluid\">
                        <div class=\"span8\">
                            <h4>
                                <i class=\"icon-pencil\"></i> Tulis komentar
                                <div class=\"pull-right\" style=\"font-size: 14px;\">";
            // line 95
            echo form_error("komentar");
            echo "</div>
                            </h4>
                            <div class=\"bg-form-komentar\" id=\"form-komentar\">
                                <form method=\"post\" action=\"";
            // line 98
            echo twig_escape_filter($this->env, site_url(("materi/detail/" . $this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "id"))), "html", null, true);
            echo "\">
                                    <p><textarea class=\"span12 texteditor-komentar\" id=\"komentar\" name=\"komentar\">";
            // line 99
            echo set_value("komentar");
            echo "</textarea></p>
                                    <p>
                                        <button class=\"btn btn-primary pull-right\">Post komentar</button>
                                        <img src=\"";
            // line 102
            echo twig_escape_filter($this->env, get_url_image_session(get_sess_data("user", "foto"), "medium", get_sess_data("user", "jenis_kelamin")), "html", null, true);
            echo "\" style=\"height:30px;width:30px; margin-right:5px;\" class=\"img-circle img-polaroid\">
                                        ";
            // line 103
            echo twig_escape_filter($this->env, get_sess_data("user", "nama"), "html", null, true);
            echo "
                                    </p>
                                    <div class=\"clear\"></div>
                                </form>
                            </div>
                            <br>

                            ";
            // line 110
            if (($this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "jml_komentar") > 0)) {
                // line 111
                echo "                                <h4><i class=\"icon-comments\"></i> ";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "jml_komentar"), "html", null, true);
                echo " Komentar</h4>

                                ";
                // line 113
                $context['_parent'] = (array) $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "komentar"));
                foreach ($context['_seq'] as $context["_key"] => $context["k"]) {
                    // line 114
                    echo "                                <div class=\"komentar\" id=\"komentar-";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"), "html", null, true);
                    echo "\">
                                    <img src=\"";
                    // line 115
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["k"]) ? $context["k"] : null), "login"), "link_image"), "html", null, true);
                    echo "\" style=\"height:25px;width:25px; margin-left:5px;\" class=\"img-circle img-polaroid pull-right\">
                                    <p><a href=\"";
                    // line 116
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["k"]) ? $context["k"] : null), "login"), "link_profil"), "html", null, true);
                    echo "\"><b>";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["k"]) ? $context["k"] : null), "login"), "nama"), "html", null, true);
                    echo "</b></a>, <small>";
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "tgl_posting"), "d F Y H:i:s"), "html", null, true);
                    echo "</small>, <small><a href=\"";
                    echo twig_escape_filter($this->env, site_url(((("materi/detail/" . $this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "id")) . "/laporkan/") . $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"))), "html", null, true);
                    echo "\" class=\"text-muted iframe-laporkan\"><i class=\"icon-bug\"></i> laporkan</a></small></p>
                                    <small>";
                    // line 117
                    echo $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "konten");
                    echo "</small>
                                </div>
                                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['k'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 120
                echo "
                                <div style=\"font-size:12px;\">
                                ";
                // line 122
                echo $this->getAttribute((isset($context["materi"]) ? $context["materi"] : null), "komentar_pagination");
                echo "
                                </div>
                            ";
            }
            // line 125
            echo "                        </div><hr>
                        <div class=\"span4\">
                            <h4><i class=\"icon-file\"></i> Materi lainnya</h4>
                            <ul class=\"unstyled ul-materi\">
                                ";
            // line 129
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["terkait"]) ? $context["terkait"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["t"]) {
                // line 130
                echo "                                <li>
                                    <div class=\"materi\">
                                        <small><a href=\"";
                // line 132
                echo twig_escape_filter($this->env, site_url(("materi/detail/" . $this->getAttribute((isset($context["t"]) ? $context["t"] : null), "id"))), "html", null, true);
                echo "\"><i class=\"";
                echo ((twig_test_empty($this->getAttribute((isset($context["t"]) ? $context["t"] : null), "file"))) ? ("icon-file") : ("icon-download"));
                echo " img-circle img-polaroid ";
                echo (((strlen($this->getAttribute((isset($context["t"]) ? $context["t"] : null), "judul")) > 33)) ? ("pull-left") : (""));
                echo "\" style=\"padding:10px; margin-right:10px;\"></i>";
                echo $this->getAttribute((isset($context["t"]) ? $context["t"] : null), "judul");
                echo "</a>
                                        </small>
                                    </div>
                                </li>
                                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['t'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 137
            echo "
                                ";
            // line 138
            if (twig_test_empty((isset($context["terkait"]) ? $context["terkait"] : null))) {
                // line 139
                echo "                                <div class=\"alert alert-info\">Tidak ada materi terkait</div>
                                ";
            }
            // line 141
            echo "                            </ul>
                        </div>
                    </div>

                ";
        } else {
            // line 146
            echo "                    <div class=\"alert alert-danger\">
                        <h3>";
            // line 147
            echo twig_escape_filter($this->env, (isset($context["error"]) ? $context["error"] : null), "html", null, true);
            echo "</h3>
                    </div>
                ";
        }
        // line 150
        echo "            </div>
        </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "detail-materi.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  375 => 150,  369 => 147,  366 => 146,  359 => 141,  355 => 139,  353 => 138,  350 => 137,  333 => 132,  329 => 130,  325 => 129,  319 => 125,  313 => 122,  309 => 120,  300 => 117,  290 => 116,  286 => 115,  281 => 114,  277 => 113,  271 => 111,  269 => 110,  259 => 103,  255 => 102,  249 => 99,  245 => 98,  239 => 95,  228 => 86,  222 => 83,  217 => 81,  213 => 80,  207 => 77,  202 => 75,  197 => 73,  192 => 71,  188 => 69,  182 => 67,  179 => 66,  177 => 65,  169 => 59,  166 => 58,  157 => 52,  153 => 51,  149 => 50,  143 => 46,  134 => 39,  131 => 38,  129 => 37,  124 => 34,  118 => 32,  112 => 31,  108 => 30,  101 => 29,  92 => 27,  88 => 26,  84 => 25,  81 => 24,  79 => 23,  75 => 22,  69 => 19,  65 => 17,  58 => 13,  54 => 12,  49 => 11,  47 => 10,  43 => 8,  40 => 7,  32 => 4,  29 => 3,);
    }
}
